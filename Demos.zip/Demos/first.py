a='abc'
print(a)
print(type(a))

a=11
print(a)
print(type(a))

a=True
print(a)
print(type(a))

a=5.3
print(a)
print(type(a))

x,y,z=10,20,30
print(x,y,z)

print(x+y)
print(y-x)
print(x*y)
print(z/x)

print(x,"+",y,"=",x+y)
print(f"{x} + {y} = {x+y}")

print(5/2)
print(5//2)
print(5%2)
import re

txt='The rain in Spain'

words=re.split("\s",txt)
print(words)

words=re.split("\s",txt,2)
print(words)

details='''1 AAA
2 BBB
3 CCC'''

#task
#split each student detail
stu=re.split("\n",details)
print(stu)

res=re.sub("\s","*",txt)
print(res)

res=re.sub("\s","*",txt,2)
print(res)
import re

txt='''line1 abc
line2 xyz
line3 bbc
'''

print(re.match('line1',txt))#match searches only in the beginning of first line
print(re.search('line1',txt))#search searches in the whole text

print(re.match('line2',txt))#None because match searches only in the beginning of first line
print(re.search('line2',txt))#search searches in the whole text

print(re.match('abc',txt))#None because match searches only in the beginning of first line
print(re.search('abc',txt))#search searches in the whole text

print(re.match('Line1',txt,re.IGNORECASE))#match searches only in the beginning of first line
print(re.search('Line1',txt,re.IGNORECASE))#search searches in the whole text

res=re.match('line1',txt)#line2
try:
    print(res.span())
    print(res.start(),res.end())
    print(res.group())
except AttributeError:
    print("Not Found")

res=re.search('line3',txt)#line4

if res:
    print("Found")
    print(res.span())
    print(res.start(),res.end())
    print(res.group())
else:
    print("Not Found")
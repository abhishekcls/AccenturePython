'''import math
print(math.sqrt(9))
print(math.pow(2,3))
print(math.floor(5.9))
print(math.ceil(5.1))'''

#print(dir(math))

'''from math import sqrt,floor

print(sqrt(9))
print(floor(2.5))'''

from math import sqrt as sq

print(sq(9))
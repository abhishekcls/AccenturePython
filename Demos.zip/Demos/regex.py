import re

print(re.match("\d{3}","123"))
print(re.match("\d{3}","123 bfdsk"))
print(re.match("\d{3}","1234"))
print(re.match("^\d{3}$","1234"))
print(re.match("^\d{3}$","555"))

'''
1. 2 or more chars
2. no numbers or spl chars
'''
print(re.match("^[A-Za-z]{2,}$","abhishek"))

amts="$100 $200 $300 $5000"

print(re.findall("\$",amts))
print(re.findall(r"\$\b\d{3}\b",amts))

text="The quick brown fox jumps over it little lazy dog"

print(re.findall(r'\b\S.{3}\b',text))
print(re.findall('[aeiou]',text))
print(re.findall('fox|bear|dog',text))

phones="9912345678 8973836323 87658274234 4734628733 7973836323"

ph=re.split("\s",phones)
print(ph)

for p in ph:
    #if re.match(r"\b\d{10}\b",p):
    #if re.match(r"^(7|8|9)\d{9}$",p):
    #if re.match(r"^[7-9][0-9]{9}$",p):
    #if re.match(r"^[7-9]\d{9}$",p):
    if re.search(r"^[7-9]\d{9}$",p):
        print(p,"Valid")
    else:
        print(p,"Invalid")

'''
Task
1. 10 digits
2. 7 8 9
'''
#tuple is immutable

fruits=("apple","banana","kiwi")
print(fruits)
print(type(fruits),type(fruits[0]))

print(fruits[2],fruits[-2])
print(fruits[:2])

#fruits[2]="orange" #TypeError because tuple is immutable
#del fruits[1] #TypeError because tuple is immutable

if "apple" in fruits:
    print("available")
else:
    print("not available")

for f in fruits:
    print(f)

t1=(1,2,3)
t2=("a","b",1)

t3=t1+t2
print(t3)

print(t3.count(1))

#del fruits
#print(fruits)#NameError: name 'fruits' is not defined

scores=[2,6,8,5,9]

print(scores)
print(type(scores),type(scores[0]))

tscores=tuple(scores)
print(tscores)
print(type(tscores),type(tscores[0]))

lscores=list(tscores)
print(lscores)
print(type(lscores))
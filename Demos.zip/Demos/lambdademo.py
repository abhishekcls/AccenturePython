'''def show(a):
    print("Hello",a)'''

show=lambda a: print("Hello",a)

show("Abhishek")

#task1

add=lambda a,b:print(a+b)

#task2

demo= lambda: print("hello")

'''def square(a):
    print(a*a)'''

square=lambda a: print(a*a)
square(5)

'''def square(a):
    return a*a'''

square=lambda a: a*a

print(square(4))
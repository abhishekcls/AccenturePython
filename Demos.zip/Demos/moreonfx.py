def abc():
    '''
    doc string
    demo
    '''
    txt='''line one
    line 2
    line3'''
    print(txt)

print(abc.__doc__)
abc()

def demoprint(a,b):
    print("Hello "+a)
    print("Hi",a)
    print("Hey {} {}".format(a,b))
    print("Welcome %s %d"% (a,b))
    print(f"Hi {a} {b}")

demoprint("Abhishek",101)

print("-"*50)

def myf(**kwargs):
    #print(kwargs["eid"],kwargs["ename"])
    for key,value in kwargs.items():
        print(key,value)
    
myf(eid=111,ename="Ramesh")
import re

phones="9912345678 8973836323 87658274234 4734628733 7973836323"

ph=re.split("\s",phones)
print(ph)

compiled_re=re.compile(r"\b[7-9]\d{9}\b")
#compiled_re=re.compile(r"^[7-9]\d{9}$")

for p in ph:
    #if re.match(r"\b\d{10}\b",p):
    #if re.match(r"^(7|8|9)\d{9}$",p):
    #if re.match(r"^[7-9][0-9]{9}$",p):
    #if re.match(r"^[7-9]\d{9}$",p):
    #if compiled_re.match(p):
    if compiled_re.search(p):
        print(p,"Valid")
    else:
        print(p,"Invalid")

print(compiled_re.findall(phones))
#task
names="Om Abhishek Prateek 0mveer ravi"
names=re.split("\s",names)
compiled=re.compile("^[A-Za-z]{2,}$")

for n in names:
    if compiled.match(n):
        print(n,"Valid")
    else:
        print(n,"Invalid")
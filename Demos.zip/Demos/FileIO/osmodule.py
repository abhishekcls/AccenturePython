import os

#print(os.system("dir"))#system can run cmd commands only not powershell but you can run this python file on powershell

path=os.getcwd()
print(path)

path+="\\file1.txt"

print(path)

dirname,filename=os.path.split(path)
print(dirname)
print(filename)

#os.mkdir("abhishek")
os.chdir("abhishek")
path=os.getcwd()
print(path)

print("-"*10)
ff=os.listdir()

for f in ff:
    #if f.endswith(".txt"):
    print(f)
'''
r read(default)
w write
a append
'''

fp=open("file1.txt")
print(fp.tell())#0
content=fp.read(4)
print(content)
print(fp.tell())#4
fp.seek(0)
print(fp.read(15))
print(fp.tell())#15
fp.seek(0,2)#seek end
'''
seek second parameter

0: sets the reference point at the beginning of the file 
1: sets the reference point at the current file position 
2: sets the reference point at the end of the file 
'''
print(fp.read())
print(fp.tell())#43

if not fp.closed:
    fp.close()
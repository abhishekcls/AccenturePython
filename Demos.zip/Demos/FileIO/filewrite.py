f=open("file1.txt","a")

f.write(input("Enter text: ")+"\n")
f.close()

print("File Written")
f=open("file1.txt")
content=f.read()
f.close()

fw=open("file1copy.txt","w")
fw.write(content)
fw.close()

print("File copied")
try:
    f=open("file1.txt")
    #print(f.read())
    for l in f:
        print(l)
except FileNotFoundError:
    print("File Not found")
finally:
    if not(f.closed):
        f.close()

#task
#copy file1.txt into file1copy.txt

#hw task
#save some phone numbers/names in a file and validate the data in the file

#counting vowels
import re
try:
    f=open("file1.txt")
    content=f.read()
    res=re.findall('[aeiouAEIOU]',content)
    print("Vowels count:",len(res))
except FileNotFoundError:
    print("File Not found")
finally:
    if not(f.closed):
        f.close()

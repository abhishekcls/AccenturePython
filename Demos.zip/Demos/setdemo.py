fruits={"apple","banana","kiwi"}
print(fruits)
print(type(fruits))

if "apple" in fruits:
    print("available")
else:
    print("not available")

fruits.add("orange")

for f in fruits:
    print(f)

fruits.update({"cherry","grapes"})
#fruits.update(("cherry","grapes"))
#fruits.update(["cherry","grapes"])
print(fruits)

print(len(fruits))
#fruits.remove("guava")#KeyError: 'guava'
fruits.discard("guava")
print(fruits)
print(len(fruits))

#print(fruits[1])#TypeError: 'set' object is not subscriptable
print(fruits.pop())
print(fruits)

#fruits.clear()
#print(fruits)

#del fruits
#print(fruits)#NameError: name 'fruits' is not defined

s1={1,2,3,4}
s2={4,5}

#s3=s1+s2 #TypeError: unsupported operand type(s) for +: 'set' and 'set'

s3=s1.union(s2)
print(s3)

s3=s1.intersection(s2)
print(s3)

s3=s1.difference(s2)
print(s3)

set1=set(("apple","banana"))
print(set1)
emp={
    "eid":101,
    "ename":"Abhishek"
    }

print(emp)
print(type(emp))

print(emp["eid"])
print(emp["ename"])

print(emp.get("eid"))
emp["ename"]="Deepak"

print(emp)
print("--------")

for key in emp:
    print(key)

print("--------")

for value in emp.values():
    print(value)

print("--------")

for key in emp:
    print(key,emp[key])

print("--------")

for k,v in emp.items():
    print(k,v)

print("--------")

if "ename" in emp:
    print("its there")

print("--------")
print(emp)
print(len(emp))
emp["sal"]=75000
print(emp)
print(len(emp))
print("--------")

#emp.pop("sal")
#emp.popitem()
del emp["sal"]
print(emp)
print("--------")

#del emp

emp2=emp.copy()
print(emp2)
emp.clear()
print(emp)

print(type(emp2))

emp3=dict(eid=102,ename="Ratan")
print(emp3)
print(type(emp3))

nestedemp={
    "eid":101,
    "ename":"Abhishek",
    "address":{
        "city":"BLR",
        "country":"India"
        }
    }

print(nestedemp)
print(type(nestedemp))
a=100 #global

print(a)

'''def abc():
    a=200 #local
    print(a)
'''

def abc():
    global a
    a=200
    print(a)

abc()
print(a)

print("-"*10)
#Closure
'''
def outer():
    x=10#local
    def inner():
        print(x)

    return inner

fx=outer()
fx()
'''
def outer():
    x=10#local
    def inner():
        nonlocal x
        x=20
        print(x)#20
    inner()
    print(x)#10

outer()
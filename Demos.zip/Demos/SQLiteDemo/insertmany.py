import sqlite3

conn=sqlite3.connect("abhishek.db")

cursor=conn.cursor()
'''
cursor.execute("""create table mytab
(
    id text,
    name text
)""")
'''

rows=[('4','DDD'),('5','EEE')]
cursor.executemany("insert into mytab values(?,?)",rows)

conn.commit()
conn.close()
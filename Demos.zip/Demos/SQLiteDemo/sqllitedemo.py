import sqlite3

conn=sqlite3.connect("abhishek.db")

cursor=conn.cursor()
'''
cursor.execute("""create table mytab
(
    id text,
    name text
)""")
'''

#cursor.execute("insert into mytab values('1','AAA')")
#task
'''
take id and name from user and then insert in mytab
'''

id=input("ID: ")
#name=input("Name: ")
#cursor.execute(f"insert into mytab values('{id}','{name}')")
#cursor.execute(f"update mytab set name='{name}' where id='{id}'")
#cursor.execute(f"delete from mytab where id='{id}'")
#stu={"id":"4","name":"DDD"}
#cursor.execute("insert into mytab values('"+stu["id"]+"','"+stu["name"]+"')")

#cursor.execute("Select * from mytab")
#print(cursor.fetchall())

#cursor.execute(f"select * from mytab where id='{id}'")
cursor.execute("select * from mytab where id=?",[(id)])
res=cursor.fetchall()

if len(res)==0:
    print("Not Found")
else:
    print("Found")
    print(res)

conn.commit()
conn.close()
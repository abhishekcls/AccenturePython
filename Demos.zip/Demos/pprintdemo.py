from pprint import pprint

names=['abc','xyz']

print(names)
pprint(names)

names=['abc','xyz','sdfgsd','ajdgfaj','ajvfajfa','ajfajhsa','kfjgakfgsd','ksdgfksafsfds']

print(names)
pprint(names)
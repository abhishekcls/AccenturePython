'''class Demo:
    pass

d=Demo()
print(d.__class__)
'''

class Demo:
    name=''
    def __init__(self,name):
        print("cons")
        self.name=name
    
    def __del__(self):
        print("deconstructor")
        self.name=''

    def disp(self):
        print("Hi",self.name)

d=Demo("Abhishek")
d.disp()
d2=Demo("Deepak")
d2.disp()

#d.show()#AttributeError

'''
Task: create a class Car with following attributes
following 2 variables should not be accessible outside
1. engine
2. seats
disp method -> displays engine and seats
--------
maruti800=Car("Suzuki",5)
maruti800.disp()
'''

class Car:
    def __init__(self,e,s):
        self.__engine=e
        self.__seats=s

    def disp(self):
        print(f"{self.__engine} {self.__seats}")

maruti800=Car("Suzuki",5)
maruti800.disp()

hondacity=Car("Honda",7)
hondacity.disp()
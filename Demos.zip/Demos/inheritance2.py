


class Parent:
    def __init__(self) -> None:
        print("P Cons")

    def __del__(self):
        print("P Des")

class Child(Parent):
    def __init__(self) -> None:
        super().__init__()
        print("C Cons")

    def __del__(self):
        print("C Des")
        super().__del__()

c=Child()
age=int(input("Enter your age: "))
#single line comment
#print(age)
#print(type(age))

if age<13:
    if age<5:#nested if
        print("Infant")
    else:
        print("Child")
elif age<20:
    print("Teenager")
elif age<60:
    print("Adult")
else:
    print("Senior Citizen")

'''if age>=18:
    print("Eligible to Vote")
else:
    print("Not eligible to Vote")
'''

#Task
'''
take 3 sub marks(out of 100) from user and display the following
1. Total
2. Percentage/Average
3. Result
Percentage >=50 is Pass else Fail
'''


'''s1=int(input("Enter sub1 marks: "))
s2=int(input("Enter sub2 marks: "))
s3=int(input("Enter sub3 marks: "))

total=s1+s2+s3
print("Total",total)
per=total//3
print("Percentage",per)

if per>=50:
    print("Pass")
else:
    print("Fail")
    '''
fruits=["apple","banana","kiwi"]*2
print(fruits)
'''
for i in range(1,11):
    if i==6:
        continue
    if i==8:
        break
    print(i)
'''

def add(a,b,c=0):
    print(a+b+c)

add(1,4)
#add(1)#TypeError: add() missing 1 required positional argument: 'b'
add(1,2,3)#TypeError: add() takes 2 positional arguments but 3 were given [if c=0 is not mentioned]

str='DemoString'
print(str[0:10:2])
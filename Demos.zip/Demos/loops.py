'''for i in range(5):
    print(i,end=' ')
'''
'''
#WAP to display a table of a number
n=int(input("Enter a num: "))

for i in range(1,11):
    print(n*i)
    #print(n,"x",i,"=",n*i)
'''
#for i in range(1,11,2):
#    print(i)

for i in range(10,0,-1):
    print(i)
else:
    print("for done")

i=1
while i<=5:
    print(i)
    i=i+1
else:
    print("while done")

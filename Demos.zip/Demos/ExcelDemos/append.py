import openpyxl

## initializing the xlsx
xlsx = openpyxl.Workbook()

## creating an active sheet to enter data
sheet = xlsx.active

## creating data to append
f=open("mycsv.csv")
for row in f:
    sheet.append(row.split(","))
    #print(row)


## saving the xlsx file using 'save' method
xlsx.save('appendingcsvdemo.xlsx')
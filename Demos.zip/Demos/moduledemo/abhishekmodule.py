'''
this is a superb module
it will solve all your problems
'''

def add(a,b):
    '''
    addition function to make your addition easy
    '''
    print("abhishek module add =>",a+b)


print(__name__)

if __name__=="__main__":
    add(2,5)
import abhishekmodule
#import abhishekmodule as a
#from abhishekmodule import add
#from abhishekmodule import add as ad
 

abhishekmodule.add(1,4)
#a.add(1,4)
print(abhishekmodule.add.__doc__)

print(dir(abhishekmodule))

print(abhishekmodule.__doc__)

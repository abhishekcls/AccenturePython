'''def function1():
    print("my function")

function1()

def abc():
    pass

abc()
'''

'''def add(a,b):
    print(f"{a}+{b}={a+b}")

add(1,4)
add(b=5,a=2)
'''

def add(a,b):
    return a+b

print(add(1,4))

def add(a,b):
    print(a+b)

print(add(1,4))
print(add(3,4))

def add(*args):
    s=0
    for i in args:
        s=s+i
        print(i,end="+")
    print("=>",s)

add(1,2)
add(1,2,3)
add(1,3,6,67,6,34,5,76,6,87,9)

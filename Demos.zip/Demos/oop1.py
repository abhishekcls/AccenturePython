'''
class Student:
    name=''#public
    def show(self):
        print("Hello",self.name)


s=Student()#object
s.name="Kapil"
print(s.name)
s.show()
'''

class Demo:
    a="public"
    _b="protected"
    __c="private"
    def show(self):
        print(self.a,self._b,self.__c)

d=Demo()
#print(d.__c) #AttributeError
d.show()
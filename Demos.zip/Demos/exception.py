#print("Hi")

'''try:
    print(a)
except NameError:
    print("Variable a is not declared")


try:
    a=int(input("enter first number: "))
    b=int(input("enter second number: "))
    c=a/b
    print(c)
except ValueError:
    print("Enter numbers only")
except ZeroDivisionError:
    print("cannot / by 0")
else:
    print("No Error/Exception")
finally:
    print("finally")
'''

'''import sys

try:
    a=int(input("enter first number: "))
    b=int(input("enter second number: "))
    c=a/b
    print(c)
except:
    exc_type,value,traceback=sys.exc_info()
    #print(exc_type.__name__)
    print(f"{exc_type.__name__}: {value}")
    #print(sys.exc_info())
    #print(traceback)
else:
    print("No Error/Exception")
finally:
    print("finally")

print("Done")
'''

a=-5

try:
    if a<0:
        raise Exception("Cannot be less than 0")
except:
    print("exception")


b="abc"

if not type(b) is int:
    raise TypeError("only numbers")
str='Hello World!'

print(str)
print(str[0])
print(str[2:7])
print(str[2:])
print(str[:5])

str='''line 1
line 2'''
print(str)
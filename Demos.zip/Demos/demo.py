#print('hello')

'''
task

Take 5 numbers from user and store it in a list. display the following
1. Total
2. Avg
3. Min
4. Max
5. Search a number

1 2 3 4 5
ser: 7
Not Found
'''

mylist=[]
print(mylist)
print("Enter 5 numbers")
total=0

for i in range(0,5):
    temp=int(input("enter number: "))
    mylist.append(temp)
    total=total+temp

print(mylist)
print("total",total)
print("avg",total/len(mylist))

#print("min",min(mylist))
#print("max",max(mylist))

min=max=mylist[0]

for i in range(1,mylist.__len__()):
    if min>mylist[i]:
        min=mylist[i]
    if max<mylist[i]:
        max=mylist[i]

print("min",min)
print("max",max)

ser=int(input("Enter a number to search: "))

if ser in mylist:
    print("Found")
else:
    print("Not Found")
'''
[1,4,7,5,8]
list -> 5

map -> 5
[2,5,8,6,9]

filter -> 0-5
[4,8]

reduce -> 1
'''


from functools import reduce


nums=[1,4,7,5,8]
print(nums)

def addone(n):
    return n+1

#result=list(map(addone,nums))

result=list(map(lambda n:n+1,nums))

print(result)
print(type(result))

'''
1. square of all numbers
2. extract the even numbers
'''

squares=list(map(lambda n:n*n,nums))
print(squares)

even=list(filter(lambda n:n%2==0,nums))
print(even)

sum=reduce((lambda p,c:p+c),nums)
print(sum)

#task : find max
# maxval=reduce(lambda p,c:max(p,c),nums)
# print(maxval)

maxval=reduce(lambda p,c:c if c>p else p,nums)
print(maxval)

names=["Abhishek","Harish"]
print(names)
upperlist=[i.upper() for i in names] #list comprehension
print(upperlist)

odds=[x for x in range(1,11) if x%2!=0]
print(odds)

twice=[2*x for x in range(1,6)]
print(twice)

twice=list(map(lambda x:2*x,range(1,6)))
print(twice)

chars=[c for c in "Abhishek"]
print(chars)

#task
mylist=[2,5,8,4]
#display half of each number

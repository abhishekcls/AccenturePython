scores=[2,6,8,5,9]

print(scores)
print(type(scores),type(scores[0]))

print(scores[2])
#print(scores[7])#IndexError: list index out of range
print(scores[-2])
print(scores[2:4])
print(scores[:2])
print(scores[2:])

print(len(scores))

fruits=["apple","banana","kiwi"]
print(fruits)
print(type(fruits),type(fruits[0]))

print(fruits[2],fruits[-2])

if "apple" in fruits:
    print("available")
else:
    print("not available")

for f in fruits:
    print(f)

fruits.append("cherry")
print(fruits)

fruits.insert(1,"grapes")
print(fruits)

fruits[3]="orange"
print(fruits)

fruits.remove("banana")
print(fruits)

fruits.pop()
print(fruits)

del fruits[0]
print(fruits)

#del fruits
#print(fruits)

#fruits.clear()
#print(fruits)

copy=fruits.copy()
fruits.clear()
print(copy)
print(fruits)

l1=[1,2,3]
l2=[3,6,7]

l3=l1+l2
print(l3)

l4=["abc","xyz"]
#l5=l3+l4
print(l4)
print(len(l4))
l4.extend(l3)
print(l4)
print(len(l4))

print(l4.count(3))






'''class Parent:
    def disp(self):
        print("Parent")

class Child(Parent):#inheritance
    pass

c=Child()
c.disp()'''

'''p=Parent()
p.disp()
print(type(p))
'''

#polymorphism
class Parent:
    def disp(self):
        print("Parent")

class Child(Parent):#inheritance
    def disp(self):
        Parent.disp(self)
        print("Child")

c=Child()
c.disp()

#p=Parent()
#p.disp()